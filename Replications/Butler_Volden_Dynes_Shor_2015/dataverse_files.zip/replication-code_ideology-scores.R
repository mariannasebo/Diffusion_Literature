# set working directory and load needed packages

setwd("../../Dropbox/Diffussion - Experiment/Accepted Version and Replication")

library(plyr)
library(pscl)
library(car)
library(ggplot2)
library(haven)


###

r<-function(x, dig=2) { return (round(x,dig)) }


### 


municipal = read.dta("replication-data_issue-positions.dta",convert.underscore=T)
start.pos = which(names(municipal)=="npat.soc.4")

leg.data = municipal[,1:(start.pos-1)]
votes = municipal[,start.pos:ncol(municipal)]

# set up roll call object

rc.full <- rollcall(data=votes,
                    vote.names=colnames(votes),legis.data=leg.data,
                    desc="Municipal Officials 2012", 
                    yea=1, nay=0, missing=NA)

#print(summary(rc,verbose=TRUE))

cat("Roll calls:",rc.full$m,"\n")
legis.sum = as.data.frame(summary(rc.full,verbose=TRUE)$legisTab); 

 
legismin=5; lop =1

rc = dropRollCall(rc.full,dropList=list(legisMin=legismin,lop=lop),debug=T)    

cat("After culling, remaining roll calls:",rc$m,"\n")

print(summary(rc))

prop.table(table(leg.data$round))
prop.table(table(rc$legis.data$round))

table(leg.data$round)-table(rc$legis.data$round)

d= 1
n.iter = 110000; n.thin = 200
n.iter = 510000; n.thin = 500

recodes = recode(rc$legis.data$party, "'D'=-1;'R'=1;else=0")
xstart=as.matrix(recodes)
bstart=matrix(rnorm(rc$m*(d+1),.5,.05),ncol=(d+1))
stvals=list(x=xstart,b=bstart)

sink(str_c("municipal estimation ",(n.iter-10000),".txt"))
system.time(mcmc <- ideal(rc, d=1, normalize=TRUE, store.item=TRUE, maxiter=n.iter, burnin=10000,thin=n.thin,verbose=T,startvals=list(x=xstart)))
sink()

save(rc,mcmc,file=str_c("municipal mcmc ",(n.iter-10000),".Rdata"))

####

load(file="municipal mcmc 5e+05.Rdata")

mcmc$call
r(summary(mcmc,prob=.9)$party.quant)
#summary(mcmc, verbose=T)

muni = data.frame(summary(mcmc)$xm,summary(mcmc)$xsd,rc$legis.data); names(muni)[1:2]=c("score","sd")

names(muni) = str_replace_all(names(muni),"\\.","_")

write_dta(muni,"replication-data_ideology-scores.dta")
