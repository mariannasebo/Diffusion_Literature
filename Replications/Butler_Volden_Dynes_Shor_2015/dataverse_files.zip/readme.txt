*****************************************************
**  PROJECT:  "Ideology, Learning, and Policy Diffusion: 
Experimental Evidence
", American Journal of Political Science
**  AUTHORS: Daniel M. Butler, Craig Volden, Adam M. Dynes, Boris Shor
**  DESCRIPTION: Readme File for Replication Files
**  DATE: 6 May 2015
*****************************************************


Excluded Data and Associated Figures and Tables

	To protect the anonymity of respondents in the 2012 American Municipal Official Survey (AMOS), we do not provide the information on the demographics of respondents' municipalities in the public version of the data sets. Interested researchers who believe they need to have access to these data should contact the authors directly to receive access under the condition that the data remain confidential.
	
	To encourage local officials to participate in the 2012 AMOS, we promised to keep their responses confidential. As such, we maintain their anonymity in the replication files and do not include any identifying information in this data set, including demographic data about the respondents' municipalities.  Providing the demographic data would provide information, such as a municipality's population according to the U.S. Census, that could then be used to identify which cities had respondents and the individual responses of officials from those cities. From there, any mayors in the data set would be identified, and given the small size of many legislative bodies in municipalities, it would be easy for officials in these municipalities to identify which of their colleagues participated in the survey once they knew that at least one of them did so. 
	
	Without these data, users will not be able to recreate Figures A1, A2, and A3. In addition, they will not be able to recreate the models in the regressions that use the full set of municipality characteristics. These include models in Tables 1, 2, D1, S2, and S3 as well as the descriptive statistics reported in Tables C1 and C2.
	
	For the purposes of verifying the analysis in this paper with the American Journal of Political Science (AJPS) and its third party replication organization, we included versions of the data sets and code that included all of the variables needed to replicate all of the models in Tables 1, 2, D1, S2, and S3 as well as the descriptive statistics reported in Tables C1 and C2.


Files in replication files:

	DATA FILES
	
	1. replication-data_experiment1_public.dta: 
		
		Summary: Public version of the Stata data set that contains  variables (except for the variable "score", which is a measure of "Policymaker Conservatism") needed to replicate the tables and figures related to experiment #1 that do not involve any variables on the demographics of respondents' municipalities.
		
		Unit of Analysis: Individual elected municipal officials
		
		Source of Data: The primary source of the data is the 2012 AMOS conducted in the summer of 2012. See "Appendix A: Details of the Survey" for more information about this survey. The other data sources for each variable are indicated in the codebook. 		
	
	2. replication-data_experiment2_public.dta: 
		
		Summary: Public version of the Stata data set that contains  variables (except for the variable "score", which is a measure of "Policymaker Conservatism") needed to replicate the tables and figures related to experiment #2 that do not involve any variables on the demographics of respondents' municipalities.
		
		Unit of Analysis: Individual elected municipal officials
		
		Source of Data: The primary source of the data is the 2012 AMOS conducted in the summer of 2012. See "Appendix A: Details of the Survey" for more information about this survey. The other data sources for each variable are indicated in the codebook.

	3. replication-data_issue-positions.dta:
	
		Summary: Stata data set with respondents' answers to a random selection of 28 out of 53 issue position questions. Respondents' answers to these questions are used to calculate ideal point estimate of respondents' ideological preferences. The ideal point estimate is referred to as "Policymaker Conservatism" in the paper.

		Source of Data: The source of the data is the 2012 AMOS conducted in the summer of 2012. See "Appendix A: Details of the Survey" for more information about this survey.	
	
	4. replication-data_ideology-scores.dta
	
		Summary: Stata data set of the ideal point estimate of respondents' ideological preferences. The ideal point estimate is referred to as "Policymaker Conservatism" in the paper.

		Source of Data: The data is created using the data in the Stata data set "replication-data_issue-positions.dta", which comes from the 2012 AMOS conducted in the summer of 2012. See "Appendix A: Details of the Survey" for more information about this survey.		
	
	
	CODE FILES
	
	1. replication-code_public.do: Stata do file that contains code to replicate the the tables and figures in the paper that do not involve any variables on the demographics of respondents' municipalities. This version of the code works with the public version of the replication data sets, " replication-data_experiment1_public.dta" and replication-data_experiment2_public.dta". The code was run using two different versions of Stata: Stata/IC 11.2 for Windows (64-bit x86-64) and Stata/MP 13.1 for Mac (64-bit Intel). Please not that the code for running the generalized additive models (as reported in Table S3) only works in Stata on Windows.
	
	2. replication-code_ideology-scores.R: R code that is used to create the data set "replication-data_ideology-scores.dta" and calculate ideal point estimate of respondents' ideological preferences based on respondent's answers to a random selection of 28 out of the 53 issue position questions as recoded in the data set "replication-data_issue-positions.dta". 
	
	
	SUPPORT FILES
	
	1. codebook.txt: Contains description and source of each variable in the data files.

	
