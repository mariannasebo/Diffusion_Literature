
##### 0 ToC BJPolS Analysis v2020-06-06 ----

# 1 Prerequisites
# 2 Descriptives
# 3 Regression models & table: "availability"
# 4 Interaction models & table: "representativeness" and "anchoring"
# 5 Interaction plots



##### 1 Prerequisites ----

  # Load packages
library(lme4)
library(stargazer)
library(tidyverse)
library(ggeffects)
library(gtable)
library(grid)
library(ggpubr)
library(texreg)
library(summarytools)
library(skimr)
library(svglite)

  # Load data
load("dyadic_data_for_analyses.Rdata")


  # A note on nomenclature:
  # t0  = focal election		 (e.g.: 10)
  # t-1 = past election		 (e.g.:  9)
  # t-2 = previous election (e.g.:  8)

  # p310 = vote share at t0 (level)

  # l1 = past vote share (level)
  # d1 = change between t0  and t-1 => "past change/move"
  # d2 = change between t-1 and t-2 => "previous change/move" (cf. Adams et al. 2004)



##### 2 Descriptive insights ----
  
  # Descriptive account dependent variable(s)
dyadic_df %>% select(cosine_similarity, jaccard_similarity) %>% descr()

  # Descriptive account receiver attributes
dyadic_df %>% select(p310.i, l1_voteshare.i, d1_landslide.i, d2_landslide.i, d1_vote.i, d2_vote.i) %>% descr()

  # Descriptive account sender attributes
dyadic_df %>% select(p310.j, l1_voteshare.j, d1_landslide.j, d2_landslide.j, d1_vote.j, d2_vote.j) %>% descr()

  # Descriptive account commonalities
dyadic_df %>% select(re_use, competitor,same_famofnat, same_gov, same_epfaction, same_ipo, neighbor, sender_gov) %>% freq()

  # Descriptive account of cosine similarity within a family of nations
dyadic_df %>% filter(famofnation.i == famofnation.j) %>% group_by(famofnation.i) %>% select(cosine_similarity) %>% skim()

  # Example of Australia's National Party 2010 vs. New Zealand’s Progressive Party 2008
dyadic_df %>% filter(abs_diff_RILE < 1 & cosine_similarity < 0.2 & iso.i == 36 & iso.j == 554) %>% View()

  # Countries and time frame
dyadic_df %>% select(iso.i) %>% unique()
dyadic_df %>% select(year.i) %>% descr()

  # Bivariate correlation of cosine similarity and absolute difference in RILE scores
cor(dyadic_df$cosine_similarity, dyadic_df$abs_diff_RILE)





##### 3 Regression models for each commonality ----

m1 <- lmer(cosine_similarity ~ re_use + competitor                  + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m2 <- lmer(cosine_similarity ~ re_use + competitor + sender_gov     + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m3 <- lmer(cosine_similarity ~ re_use + competitor + same_gov       + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m4 <- lmer(cosine_similarity ~ re_use + competitor + same_epfaction + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m5 <- lmer(cosine_similarity ~ re_use + competitor + same_ipo       + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m6 <- lmer(cosine_similarity ~ re_use + competitor + same_famofnat  + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)

m8 <- lmer(cosine_similarity ~ re_use + competitor + sender_gov + same_gov + same_epfaction + same_ipo + same_famofnat + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)


  # View
screenreg(l = list(m1, m2, m3, m4, m5, m6, m8), doctype = FALSE, center = FALSE, caption = "", digits = 3, stars = c(0.001, 0.01, 0.05))

  # Output to transfer to Word
htmlreg(l = list(m1, m2, m3, m4, m5, m6, m8), doctype = FALSE, center = FALSE, caption = "", digits = 3, stars = c(0.001, 0.01, 0.05), file = "table02_forWord_regression_models.html")





##### 4 Regression models with interaction of sender/receiver attributes ----

  # Sender attribute (party j), i.e. "representativeness"
m1ja <- lmer(cosine_similarity ~ re_use * d2_vote.j + competitor                  + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m1jb <- lmer(cosine_similarity ~ re_use + competitor * d2_vote.j                  + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m2j  <- lmer(cosine_similarity ~ re_use + competitor + sender_gov * d1_vote.j     + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m3j  <- lmer(cosine_similarity ~ re_use + competitor + same_gov * d1_vote.j       + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m4j  <- lmer(cosine_similarity ~ re_use + competitor + same_epfaction * d1_vote.j + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m5j  <- lmer(cosine_similarity ~ re_use + competitor + same_ipo * d1_vote.j       + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m6j  <- lmer(cosine_similarity ~ re_use + competitor + same_famofnat * d1_vote.j  + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)

  # Predicted values at specified values of covariates
m1ja_pred <- ggpredict(m1ja, terms = c("d2_vote.j [-30:30]"), condition = c("re_use" = 1, "competitor" = 0)                       , type = "fe", ci.lvl = 0.9)
m1jb_pred <- ggpredict(m1jb, terms = c("d2_vote.j [-30:30]"), condition = c("re_use" = 0, "competitor" = 1)                       , type = "fe", ci.lvl = 0.9)
m2j_pred  <- ggpredict(m2j,  terms = c("d1_vote.j [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "sender_gov" = 1)     , type = "fe", ci.lvl = 0.9)
m3j_pred  <- ggpredict(m3j,  terms = c("d1_vote.j [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "same_gov" = 1)       , type = "fe", ci.lvl = 0.9)
m4j_pred  <- ggpredict(m4j,  terms = c("d1_vote.j [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "same_epfaction" = 1) , type = "fe", ci.lvl = 0.9)
m5j_pred  <- ggpredict(m5j,  terms = c("d1_vote.j [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "same_ipo" = 1)       , type = "fe", ci.lvl = 0.9)
m6j_pred  <- ggpredict(m6j,  terms = c("d1_vote.j [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "same_famofnat" = 1)  , type = "fe", ci.lvl = 0.9)



  # Receiver attribute (party i), i.e. "anchoring"
m1ia <- lmer(cosine_similarity ~ re_use * d2_vote.i + competitor                  + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m1ib <- lmer(cosine_similarity ~ re_use + competitor * d2_vote.i                  + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m2i  <- lmer(cosine_similarity ~ re_use + competitor + sender_gov * d2_vote.i     + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m3i  <- lmer(cosine_similarity ~ re_use + competitor + same_gov * d2_vote.i       + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m4i  <- lmer(cosine_similarity ~ re_use + competitor + same_epfaction * d2_vote.i + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m5i  <- lmer(cosine_similarity ~ re_use + competitor + same_ipo * d2_vote.i       + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)
m6i  <- lmer(cosine_similarity ~ re_use + competitor + same_famofnat * d2_vote.i  + as.factor(decade.i) + (1 | elecid.i) + (1 | elecid.j), data = dyadic_df)

  # Predicted values at specified values of covariates
m1ia_pred <- ggpredict(m1ia, terms = c("d2_vote.i [-30:30]"), condition = c("re_use" = 1, "competitor" = 0)                       , type = "fe", ci.lvl = 0.9)
m1ib_pred <- ggpredict(m1ib, terms = c("d2_vote.i [-30:30]"), condition = c("re_use" = 0, "competitor" = 1)                       , type = "fe", ci.lvl = 0.9)
m2i_pred  <- ggpredict(m2i,  terms = c("d2_vote.i [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "sender_gov" = 1)     , type = "fe", ci.lvl = 0.9)
m3i_pred  <- ggpredict(m3i,  terms = c("d2_vote.i [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "same_gov" = 1)       , type = "fe", ci.lvl = 0.9)
m4i_pred  <- ggpredict(m4i,  terms = c("d2_vote.i [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "same_epfaction" = 1) , type = "fe", ci.lvl = 0.9)
m5i_pred  <- ggpredict(m5i,  terms = c("d2_vote.i [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "same_ipo" = 1)       , type = "fe", ci.lvl = 0.9)
m6i_pred  <- ggpredict(m6i,  terms = c("d2_vote.i [-30:30]"), condition = c("re_use" = 0, "competitor" = 0, "same_famofnat" = 1)  , type = "fe", ci.lvl = 0.9)





##### 5 Interaction Plots ----


  ### * Interaction Plots - sender attribute aka "representativeness" ----


## *** Graphs m1ja recycling ----
m1ja_plot <-
  ggplot() +
  geom_ribbon(data = m1ja_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m1ja_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  labs(title = "Recycling", y = "REPRESENTATIVENESS (sender attribute) \n Predicted similarity") +
  theme_minimal() +
  theme(axis.title.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.text.x = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m1ja_plot)

# Density of sender attribute
m1ja_dens <- ggplot(dyadic_df, aes(d2_vote.j)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m1ja_dens)

# convert plots to gtable objects
m1ja_plotGrob <- ggplotGrob(m1ja_plot)
m1ja_densGrob <- ggplotGrob(m1ja_dens)

m1ja_combo <- rbind(m1ja_plotGrob, m1ja_densGrob, size = "first") # stack the two plots
panels <- m1ja_combo$layout$t[grep("panel", m1ja_combo$layout$name)]
m1ja_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m1ja_combo)


## *** Graphs m1jb competitor ----
m1jb_plot <-
  ggplot() +
  geom_ribbon(data = m1jb_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m1jb_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  labs(title = "Competitors") +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m1jb_plot)

# Density of sender attribute
m1jb_dens <- ggplot(dyadic_df, aes(d2_vote.j)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m1jb_dens)

# convert plots to gtable objects
m1jb_plotGrob <- ggplotGrob(m1jb_plot)
m1jb_densGrob <- ggplotGrob(m1jb_dens)

m1jb_combo <- rbind(m1jb_plotGrob, m1jb_densGrob, size = "first") # stack the two plots
panels <- m1jb_combo$layout$t[grep("panel", m1jb_combo$layout$name)]
m1jb_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m1jb_combo)


## *** Graphs m2j from governments ----
m2j_plot <-
  ggplot() +
  geom_ribbon(data = m2j_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m2j_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  labs(title = "From gov.") +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m2j_plot)

# Density of sender attribute
m2j_dens <- ggplot(dyadic_df, aes(d1_vote.j)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m2j_dens)

# convert plots to gtable objects
m2j_plotGrob <- ggplotGrob(m2j_plot)
m2j_densGrob <- ggplotGrob(m2j_dens)

m2j_combo <- rbind(m2j_plotGrob, m2j_densGrob, size = "first") # stack the two plots
panels <- m2j_combo$layout$t[grep("panel", m2j_combo$layout$name)]
m2j_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m2j_combo)


## *** Graphs m3j among governments ----
m3j_plot <-
  ggplot() +
  geom_ribbon(data = m3j_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m3j_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  labs(title = "Among gov.") +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m3j_plot)

# Density of sender attribute
m3j_dens <- ggplot(dyadic_df, aes(d1_vote.j)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m3j_dens)

# convert plots to gtable objects
m3j_plotGrob <- ggplotGrob(m3j_plot)
m3j_densGrob <- ggplotGrob(m3j_dens)

m3j_combo <- rbind(m3j_plotGrob, m3j_densGrob, size = "first") # stack the two plots
panels <- m3j_combo$layout$t[grep("panel", m3j_combo$layout$name)]
m3j_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m3j_combo)


## *** Graphs m4j EP factions ----
m4j_plot <-
  ggplot() +
  geom_ribbon(data = m4j_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m4j_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  labs(title = "EP factions") +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m4j_plot)

# Density of sender attribute
m4j_dens <- ggplot(dyadic_df, aes(d1_vote.j)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m4j_dens)

# convert plots to gtable objects
m4j_plotGrob <- ggplotGrob(m4j_plot)
m4j_densGrob <- ggplotGrob(m4j_dens)

m4j_combo <- rbind(m4j_plotGrob, m4j_densGrob, size = "first") # stack the two plots
panels <- m4j_combo$layout$t[grep("panel", m4j_combo$layout$name)]
m4j_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m4j_combo)


## *** Graphs m5j TPOs  ----
m5j_plot <-
  ggplot() +
  geom_ribbon(data = m5j_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m5j_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  labs(title = "TPOs") +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m5j_plot)

# Density of sender attribute
m5j_dens <- ggplot(dyadic_df, aes(d1_vote.j)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m5j_dens)

# convert plots to gtable objects
m5j_plotGrob <- ggplotGrob(m5j_plot)
m5j_densGrob <- ggplotGrob(m5j_dens)

m5j_combo <- rbind(m5j_plotGrob, m5j_densGrob, size = "first") # stack the two plots
panels <- m5j_combo$layout$t[grep("panel", m5j_combo$layout$name)]
m5j_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m5j_combo)


## *** Graphs m6j Families of Nations  ----
m6j_plot <-
  ggplot() +
  geom_ribbon(data = m6j_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m6j_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  labs(title = "Fam. of nations") +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m6j_plot)

# Density of sender attribute
m6j_dens <- ggplot(dyadic_df, aes(d1_vote.j)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m6j_dens)

# convert plots to gtable objects
m6j_plotGrob <- ggplotGrob(m6j_plot)
m6j_densGrob <- ggplotGrob(m6j_dens)

m6j_combo <- rbind(m6j_plotGrob, m6j_densGrob, size = "first") # stack the two plots
panels <- m6j_combo$layout$t[grep("panel", m6j_combo$layout$name)]
m6j_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m6j_combo)




  ### * Interaction Plots - receiver attribute aka "anchoring ----


## *** Graphs m1ia recycling ----
m1ia_plot <-
  ggplot() +
  geom_ribbon(data = m1ia_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m1ia_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  labs(y = "ANCHORING (receiver attribute) \n Predicted similarity") +
  theme_minimal() +
  theme(axis.title.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.text.x = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m1ia_plot)

# Density of receiver attribute
m1ia_dens <- ggplot(dyadic_df, aes(d2_vote.i)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m1ia_dens)

# convert plots to gtable objects
m1ia_plotGrob <- ggplotGrob(m1ia_plot)
m1ia_densGrob <- ggplotGrob(m1ia_dens)

m1ia_combo <- rbind(m1ia_plotGrob, m1ia_densGrob, size = "first") # stack the two plots
panels <- m1ia_combo$layout$t[grep("panel", m1ia_combo$layout$name)]
m1ia_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m1ia_combo)


## *** Graphs m1ib competitor ----
m1ib_plot <-
  ggplot() +
  geom_ribbon(data = m1ib_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m1ib_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m1ib_plot)

# Density of receiver attribute
m1ib_dens <- ggplot(dyadic_df, aes(d2_vote.i)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m1ib_dens)

# convert plots to gtable objects
m1ib_plotGrob <- ggplotGrob(m1ib_plot)
m1ib_densGrob <- ggplotGrob(m1ib_dens)

m1ib_combo <- rbind(m1ib_plotGrob, m1ib_densGrob, size = "first") # stack the two plots
panels <- m1ib_combo$layout$t[grep("panel", m1ib_combo$layout$name)]
m1ib_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m1ib_combo)


## *** Graphs m2i from governments ----
m2i_plot <-
  ggplot() +
  geom_ribbon(data = m2i_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m2i_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m2i_plot)

# Density of receiver attribute
m2i_dens <- ggplot(dyadic_df, aes(d2_vote.i)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m2i_dens)

# convert plots to gtable objects
m2i_plotGrob <- ggplotGrob(m2i_plot)
m2i_densGrob <- ggplotGrob(m2i_dens)

m2i_combo <- rbind(m2i_plotGrob, m2i_densGrob, size = "first") # stack the two plots
panels <- m2i_combo$layout$t[grep("panel", m2i_combo$layout$name)]
m2i_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m2i_combo)


## *** Graphs m3i among governments ----
m3i_plot <-
  ggplot() +
  geom_ribbon(data = m3i_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m3i_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m3i_plot)

# Density of receiver attribute
m3i_dens <- ggplot(dyadic_df, aes(d2_vote.i)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m3i_dens)

# convert plots to gtable objects
m3i_plotGrob <- ggplotGrob(m3i_plot)
m3i_densGrob <- ggplotGrob(m3i_dens)

m3i_combo <- rbind(m3i_plotGrob, m3i_densGrob, size = "first") # stack the two plots
panels <- m3i_combo$layout$t[grep("panel", m3i_combo$layout$name)]
m3i_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m3i_combo)


## *** Graphs m4i EP factions ----
m4i_plot <-
  ggplot() +
  geom_ribbon(data = m4i_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m4i_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m4i_plot)

# Density of receiver attribute
m4i_dens <- ggplot(dyadic_df, aes(d2_vote.i)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m4i_dens)

# convert plots to gtable objects
m4i_plotGrob <- ggplotGrob(m4i_plot)
m4i_densGrob <- ggplotGrob(m4i_dens)

m4i_combo <- rbind(m4i_plotGrob, m4i_densGrob, size = "first") # stack the two plots
panels <- m4i_combo$layout$t[grep("panel", m4i_combo$layout$name)]
m4i_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m4i_combo)


## *** Graphs m5i TPOs  ----
m5i_plot <-
  ggplot() +
  geom_ribbon(data = m5i_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m5i_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m5i_plot)

# Density of receiver attribute
m5i_dens <- ggplot(dyadic_df, aes(d2_vote.i)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m5i_dens)

# convert plots to gtable objects
m5i_plotGrob <- ggplotGrob(m5i_plot)
m5i_densGrob <- ggplotGrob(m5i_dens)

m5i_combo <- rbind(m5i_plotGrob, m5i_densGrob, size = "first") # stack the two plots
panels <- m5i_combo$layout$t[grep("panel", m5i_combo$layout$name)]
m5i_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m5i_combo)


## *** Graphs m6i Families of Nations  ----
m6i_plot <-
  ggplot() +
  geom_ribbon(data = m6i_pred, aes(x, ymin = conf.low, ymax = conf.high), fill = "grey70") +
  geom_line(data = m6i_pred, aes(x, predicted)) +
  scale_y_continuous(limits = c(0.20, 0.75), breaks = seq(0.20, 0.75, 0.05)) +
  scale_x_continuous(limits = c(-30, 30)) +
  theme_minimal() +
  theme(axis.title = element_blank(),
        axis.ticks = element_blank(),
        axis.text = element_blank(),
        plot.title = element_text(hjust = 0.1, size = 12)
  )
#print(m6i_plot)

# Density of receiver attribute
m6i_dens <- ggplot(dyadic_df, aes(d2_vote.i)) +
  geom_density(bw = 2, fill = "grey90") +
  scale_x_continuous(limits = c(-30, 30), breaks = seq(-30, 30, 10)) +
  labs(y = "", x = "Vote gain/loss") +
  scale_y_continuous(breaks = c(0.00, 0.05)) +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),
    axis.text.x = element_text(size = 8)
  ) +
  geom_hline(yintercept = 0, colour = "white") # "removes" black x-axis line
#print(m6i_dens)

# convert plots to gtable objects
m6i_plotGrob <- ggplotGrob(m6i_plot)
m6i_densGrob <- ggplotGrob(m6i_dens)

m6i_combo <- rbind(m6i_plotGrob, m6i_densGrob, size = "first") # stack the two plots
panels <- m6i_combo$layout$t[grep("panel", m6i_combo$layout$name)]
m6i_combo$heights[panels] <- unit(c(5, 1), "null")
grid.newpage()
#grid.draw(m6i_combo)



### * Combine all graphs to Figure 1 ----

# Combine gtable objects of sender
sender_combo <- cbind(m1ja_combo, m1jb_combo, m2j_combo, m3j_combo, m4j_combo, m5j_combo, m6j_combo, size = "first") # place the seven sender plots next to each other
grid.newpage()
sender_combo_out <- grid.draw(sender_combo)

# Combine gtable objects of receiver
receiver_combo <- cbind(m1ia_combo, m1ib_combo, m2i_combo, m3i_combo, m4i_combo, m5i_combo, m6i_combo, size = "first") # place the seven receiver plots next to each other
grid.newpage()
receiver_combo_out <- grid.draw(receiver_combo)

# Write outfile for Word-SI
all_combo <- rbind(sender_combo, receiver_combo)

ggsave(file="figure1_vote.svg", plot=all_combo, width=12, height=8)

