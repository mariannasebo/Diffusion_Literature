Enrico Spolaore and Romain Wacziarg, "The Diffusion of Development", 
Quarterly Journal of Economics, vol. 124, no. 2, May 2009, pp. 469-529.

********************************************
Replication Archive
********************************************

This data archive allows replication of all of the results published in the above referenced paper. The files consist of the following:

bilateral.dta: STATA datafile containing all of the worldwide data used to compute estimates in Tables 1-8 of the published paper

bilateral_cluster.do: STATA do file running with the above datafile to produce Tables 1-8. Make sure a folder entitled "regressions" is located in the directory from which this program is run in order to store the regression output.

bilateral_europe.dta: STATA datafile containing the European data used to compute estimates in tables 9 and 10 of the published paper.

bilateral_europe.do: STATA do file running with the above datafile to produce Tables 9-10. Make sure a folder entitled "regressions" is located in the directory from which this program is run in order to store the regression output.

codes.dta: STATA datafile used to store country codes and called upon by the above two do files to create country labels when generating figure 3 (and the corresponding figure for Europe, not in the published version).

For any queries: wacziarg@ucla.edu


